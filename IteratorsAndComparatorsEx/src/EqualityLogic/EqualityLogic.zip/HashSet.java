package EqualityLogic;

import java.util.HashMap;
import java.util.Map;

public class HashSet <Person> {
    private Map<Integer, Person> map;

    public HashSet(){
        this.map = new HashMap<>();
    }

    public void add(Person person){
        map.putIfAbsent(person.hashCode(), person);

    }

    public int size(){
        return this.map.size();
    }
}
