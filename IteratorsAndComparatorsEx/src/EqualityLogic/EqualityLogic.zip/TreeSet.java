package EqualityLogic;

import java.util.*;

public class TreeSet <Person> {
    private Map<Integer, Person> map;


    public TreeSet() {
        this.map = new TreeMap<>();
    }

    public void add(Person person){
        map.putIfAbsent(person.hashCode(), person);

    }

    public int size(){
        return this.map.size();
    }
}
