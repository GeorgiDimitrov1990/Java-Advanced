import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] tokens1 = scanner.nextLine().split("\\s+");
        String name = tokens1[0] + " " + tokens1[1];
        Threeuple<String, String, String> nameAndAddress = new Threeuple<>(name, tokens1[2], tokens1[3]);
        System.out.println(nameAndAddress.toString());

        String[] tokens2 = scanner.nextLine().split("\\s+");
        boolean isDrunk = tokens2[2].equals("drunk");
        Threeuple<String, Integer, Boolean> nameAndBeers = new Threeuple<>(tokens2[0], Integer.parseInt(tokens2[1]), isDrunk);
        System.out.println(nameAndBeers.toString());

        String[] tokens3 = scanner.nextLine().split("\\s+");
        Threeuple<String, Double, String> nameAndBank = new Threeuple<>(tokens3[0], Double.parseDouble(tokens3[1]), tokens3[2]);
        System.out.println(nameAndBank.toString());

    }
}
